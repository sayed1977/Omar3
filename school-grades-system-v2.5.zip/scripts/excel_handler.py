#!/usr/bin/env python3
"""
نظام استيراد وتصدير البيانات من/إلى Excel
مدرسة عمر بن الخطاب الثانوية
"""

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from datetime import datetime
import json
import os

class SchoolGradesExcelHandler:
    """معالج استيراد وتصدير بيانات الدرجات"""
    
    def __init__(self):
        self.header_fill = PatternFill(start_color="1a5f7a", end_color="1a5f7a", fill_type="solid")
        self.header_font = Font(bold=True, color="FFFFFF", size=12)
        self.border = Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )
    
    def create_template_teachers(self, filename='teachers_template.xlsx'):
        """إنشاء قالب لاستيراد بيانات المعلمين"""
        wb = Workbook()
        ws = wb.active
        ws.title = "المعلمين"
        
        # العناوين
        headers = ['رقم', 'اسم المعلم', 'اسم المستخدم', 'كلمة المرور', 'المادة']
        ws.append(headers)
        
        # تنسيق العناوين
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num)
            cell.font = self.header_font
            cell.fill = self.header_fill
            cell.alignment = Alignment(horizontal='center', vertical='center')
            cell.border = self.border
        
        # أمثلة
        examples = [
            [1, 'أحمد محمد', 'ahmed', '123456', 'رياضيات'],
            [2, 'فاطمة علي', 'fatima', '123456', 'فيزياء'],
            [3, 'محمد حسن', 'mohammed', '123456', 'كيمياء']
        ]
        
        for example in examples:
            ws.append(example)
        
        # تعديل عرض الأعمدة
        ws.column_dimensions['B'].width = 25
        ws.column_dimensions['C'].width = 20
        ws.column_dimensions['D'].width = 20
        ws.column_dimensions['E'].width = 20
        
        wb.save(filename)
        print(f"تم إنشاء قالب المعلمين: {filename}")
        return filename
    
    def create_template_students(self, filename='students_template.xlsx'):
        """إنشاء قالب لاستيراد بيانات الطلاب"""
        wb = Workbook()
        
        # إنشاء ورقة لكل صف وفصل
        grades = ['الأول', 'الثاني']
        classes = ['1', '2', '3', '4', '5']
        
        for grade in grades:
            for class_num in classes:
                ws = wb.create_sheet(f"الصف {grade} - فصل {class_num}")
                
                # العناوين
                headers = ['رقم', 'اسم الطالب']
                ws.append(headers)
                
                # تنسيق العناوين
                for col_num, header in enumerate(headers, 1):
                    cell = ws.cell(row=1, column=col_num)
                    cell.font = self.header_font
                    cell.fill = self.header_fill
                    cell.alignment = Alignment(horizontal='center', vertical='center')
                    cell.border = self.border
                
                # إضافة 30 صف للطلاب
                for i in range(1, 31):
                    ws.append([i, f'طالب {i}'])
                
                # تعديل عرض الأعمدة
                ws.column_dimensions['B'].width = 30
        
        # حذف الورقة الافتراضية
        if 'Sheet' in wb.sheetnames:
            wb.remove(wb['Sheet'])
        
        wb.save(filename)
        print(f"تم إنشاء قالب الطلاب: {filename}")
        return filename
    
    def export_grades_by_grade(self, grade, grades_data, filename):
        """تصدير درجات صف معين"""
        wb = Workbook()
        
        classes = ['1', '2', '3', '4', '5']
        subjects = ['رياضيات', 'فيزياء', 'كيمياء', 'أحياء', 'لغة عربية', 'لغة إنجليزية', 'تاريخ', 'جغرافيا', 'دين']
        
        for class_num in classes:
            ws = wb.create_sheet(f"فصل {class_num}")
            
            # العنوان
            ws.merge_cells('A1:J1')
            title_cell = ws['A1']
            title_cell.value = f"درجات الصف {grade} الثانوي - الفصل {class_num}"
            title_cell.font = Font(bold=True, size=14, color="1a5f7a")
            title_cell.alignment = Alignment(horizontal='center', vertical='center')
            
            # العناوين
            ws.append([''])  # صف فارغ
            headers = ['رقم', 'اسم الطالب', 'التقييم', 'الواجب', 'الكشكول', 'الاختبار 1', 'الاختبار 2', 'المجموع']
            ws.append(headers)
            
            # تنسيق العناوين
            for col_num, header in enumerate(headers, 1):
                cell = ws.cell(row=3, column=col_num)
                cell.font = self.header_font
                cell.fill = self.header_fill
                cell.alignment = Alignment(horizontal='center', vertical='center')
                cell.border = self.border
            
            # إضافة البيانات (30 طالب)
            for i in range(1, 31):
                row_data = [i, f'طالب {i}', 0, 0, 0, 0, 0, 0]
                ws.append(row_data)
            
            # تعديل عرض الأعمدة
            ws.column_dimensions['B'].width = 25
            for col in ['C', 'D', 'E', 'F', 'G', 'H']:
                ws.column_dimensions[col].width = 12
        
        # حذف الورقة الافتراضية
        if 'Sheet' in wb.sheetnames:
            wb.remove(wb['Sheet'])
        
        wb.save(filename)
        print(f"تم تصدير درجات الصف {grade}: {filename}")
        return filename
    
    def export_evaluation_grades(self, grades_data, filename='evaluation_grades.xlsx'):
        """تصدير درجات التقييم فقط"""
        wb = Workbook()
        ws = wb.active
        ws.title = "درجات التقييم"
        
        # العنوان
        ws.merge_cells('A1:F1')
        title_cell = ws['A1']
        title_cell.value = "درجات التقييم - جميع الصفوف"
        title_cell.font = Font(bold=True, size=14, color="1a5f7a")
        title_cell.alignment = Alignment(horizontal='center', vertical='center')
        
        # العناوين
        ws.append([''])
        headers = ['الصف', 'الفصل', 'اسم الطالب', 'المادة', 'درجة التقييم (10)', 'المعلم']
        ws.append(headers)
        
        # تنسيق العناوين
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=3, column=col_num)
            cell.font = self.header_font
            cell.fill = self.header_fill
            cell.alignment = Alignment(horizontal='center', vertical='center')
            cell.border = self.border
        
        # تعديل عرض الأعمدة
        for col, width in [('A', 12), ('B', 10), ('C', 25), ('D', 20), ('E', 18), ('F', 20)]:
            ws.column_dimensions[col].width = width
        
        wb.save(filename)
        print(f"تم تصدير درجات التقييم: {filename}")
        return filename
    
    def export_homework_grades(self, grades_data, filename='homework_notebook_grades.xlsx'):
        """تصدير درجات الواجب والكشكول فقط"""
        wb = Workbook()
        ws = wb.active
        ws.title = "الواجب والكشكول"
        
        # العنوان
        ws.merge_cells('A1:G1')
        title_cell = ws['A1']
        title_cell.value = "درجات الواجب والكشكول - جميع الصفوف"
        title_cell.font = Font(bold=True, size=14, color="1a5f7a")
        title_cell.alignment = Alignment(horizontal='center', vertical='center')
        
        # العناوين
        ws.append([''])
        headers = ['الصف', 'الفصل', 'اسم الطالب', 'المادة', 'الواجب (5)', 'الكشكول (5)', 'المعلم']
        ws.append(headers)
        
        # تنسيق العناوين
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=3, column=col_num)
            cell.font = self.header_font
            cell.fill = self.header_fill
            cell.alignment = Alignment(horizontal='center', vertical='center')
            cell.border = self.border
        
        # تعديل عرض الأعمدة
        for col, width in [('A', 12), ('B', 10), ('C', 25), ('D', 20), ('E', 15), ('F', 15), ('G', 20)]:
            ws.column_dimensions[col].width = width
        
        wb.save(filename)
        print(f"تم تصدير درجات الواجب والكشكول: {filename}")
        return filename
    
    def export_exams_grades(self, grades_data, filename='exams_grades.xlsx'):
        """تصدير درجات الاختبارات فقط"""
        wb = Workbook()
        ws = wb.active
        ws.title = "درجات الاختبارات"
        
        # العنوان
        ws.merge_cells('A1:G1')
        title_cell = ws['A1']
        title_cell.value = "درجات الاختبارات - جميع الصفوف"
        title_cell.font = Font(bold=True, size=14, color="1a5f7a")
        title_cell.alignment = Alignment(horizontal='center', vertical='center')
        
        # العناوين
        ws.append([''])
        headers = ['الصف', 'الفصل', 'اسم الطالب', 'المادة', 'الاختبار الأول (15)', 'الاختبار الثاني (15)', 'المعلم']
        ws.append(headers)
        
        # تنسيق العناوين
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=3, column=col_num)
            cell.font = self.header_font
            cell.fill = self.header_fill
            cell.alignment = Alignment(horizontal='center', vertical='center')
            cell.border = self.border
        
        # تعديل عرض الأعمدة
        for col, width in [('A', 12), ('B', 10), ('C', 25), ('D', 20), ('E', 20), ('F', 20), ('G', 20)]:
            ws.column_dimensions[col].width = width
        
        wb.save(filename)
        print(f"تم تصدير درجات الاختبارات: {filename}")
        return filename
    
    def import_teachers(self, filename):
        """استيراد بيانات المعلمين من Excel"""
        wb = load_workbook(filename)
        ws = wb.active
        
        teachers = []
        for row in ws.iter_rows(min_row=2, values_only=True):
            if row[1]:  # التحقق من وجود اسم
                teacher = {
                    'id': row[0],
                    'name': row[1],
                    'username': row[2],
                    'password': row[3],
                    'subject': row[4]
                }
                teachers.append(teacher)
        
        return teachers
    
    def import_students(self, filename):
        """استيراد بيانات الطلاب من Excel"""
        wb = load_workbook(filename)
        students_data = {}
        
        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            students = []
            
            for row in ws.iter_rows(min_row=2, values_only=True):
                if row[1]:  # التحقق من وجود اسم
                    student = {
                        'id': row[0],
                        'name': row[1]
                    }
                    students.append(student)
            
            students_data[sheet_name] = students
        
        return students_data


def main():
    """الدالة الرئيسية - مثال على الاستخدام"""
    handler = SchoolGradesExcelHandler()
    
    print("=== نظام استيراد وتصدير البيانات ===")
    print("مدرسة عمر بن الخطاب الثانوية\n")
    
    # إنشاء القوالب
    print("1. إنشاء القوالب...")
    handler.create_template_teachers()
    handler.create_template_students()
    
    print("\n2. تصدير البيانات...")
    # تصدير درجات الصف الأول
    handler.export_grades_by_grade('الأول', {}, 'grade1_grades.xlsx')
    
    # تصدير درجات الصف الثاني
    handler.export_grades_by_grade('الثاني', {}, 'grade2_grades.xlsx')
    
    # تصدير درجات التقييم
    handler.export_evaluation_grades({})
    
    # تصدير درجات الواجب والكشكول
    handler.export_homework_grades({})
    
    # تصدير درجات الاختبارات
    handler.export_exams_grades({})
    
    print("\n✅ تم إنشاء جميع الملفات بنجاح!")
    print("\nالملفات المُنشأة:")
    print("  - teachers_template.xlsx (قالب المعلمين)")
    print("  - students_template.xlsx (قالب الطلاب)")
    print("  - grade1_grades.xlsx (درجات الصف الأول)")
    print("  - grade2_grades.xlsx (درجات الصف الثاني)")
    print("  - evaluation_grades.xlsx (درجات التقييم)")
    print("  - homework_notebook_grades.xlsx (الواجب والكشكول)")
    print("  - exams_grades.xlsx (درجات الاختبارات)")


if __name__ == '__main__':
    main()
