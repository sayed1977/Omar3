# دليل نشر المشروع على GitHub 🚀

## المتطلبات الأولية
- حساب GitHub (إذا لم يكن لديك، سجل على https://github.com)
- Git مثبت على جهازك

## الخطوات التفصيلية

### 1. إنشاء Repository جديد على GitHub

1. اذهب إلى https://github.com
2. اضغط على زر "New" أو "+" في الزاوية العلوية
3. اختر "New repository"
4. املأ البيانات:
   - **Repository name**: `school-grades-system`
   - **Description**: نظام رصد الدرجات - مدرسة عمر بن الخطاب الثانوية
   - **Visibility**: اختر Public أو Private
   - ✅ **لا تضف** README أو .gitignore أو license (موجودة مسبقاً)
5. اضغط "Create repository"

### 2. رفع المشروع إلى GitHub

افتح Terminal/Command Prompt في مجلد المشروع وقم بتنفيذ:

```bash
# الانتقال إلى مجلد المشروع
cd school-grades-system

# تهيئة Git repository
git init

# إضافة جميع الملفات
git add .

# إنشاء أول commit
git commit -m "Initial commit: نظام رصد الدرجات الإلكتروني"

# تعيين الفرع الرئيسي
git branch -M main

# ربط المشروع بـ GitHub (استبدل YOUR_USERNAME باسم المستخدم الخاص بك)
git remote add origin https://github.com/YOUR_USERNAME/school-grades-system.git

# رفع الملفات
git push -u origin main
```

**ملاحظة**: عند تنفيذ `git push`، قد يطلب منك GitHub تسجيل الدخول.

### 3. تفعيل GitHub Pages (نشر الموقع)

بعد رفع الملفات بنجاح:

1. اذهب إلى صفحة Repository على GitHub
2. اضغط على "Settings" (الإعدادات)
3. في القائمة الجانبية، اضغط على "Pages"
4. في قسم "Source":
   - اختر Branch: **main**
   - اختر Folder: **/ (root)**
5. اضغط "Save"

⏳ **انتظر 1-2 دقيقة** حتى ينشر GitHub الموقع

6. سيظهر رابط الموقع في أعلى الصفحة:
   ```
   Your site is published at https://YOUR_USERNAME.github.io/school-grades-system/
   ```

### 4. التحقق من نجاح النشر

افتح الرابط في المتصفح وتأكد من:
- ✅ ظهور الصفحة الرئيسية بشكل صحيح
- ✅ عمل تسجيل الدخول
- ✅ عمل جميع الميزات

## تحديث المشروع لاحقاً

عند إجراء تعديلات على المشروع:

```bash
# إضافة التعديلات
git add .

# إنشاء commit جديد
git commit -m "وصف التعديلات"

# رفع التعديلات
git push
```

سيتم تحديث الموقع تلقائياً خلال 1-2 دقيقة.

## إضافة متعاونين (اختياري)

لإضافة معلمين آخرين ليتمكنوا من التعديل:

1. اذهب إلى Settings → Collaborators
2. اضغط "Add people"
3. أدخل اسم المستخدم أو البريد الإلكتروني
4. اختر الصلاحيات المناسبة

## حماية الفرع الرئيسي (اختياري)

لحماية main branch من التعديلات المباشرة:

1. Settings → Branches
2. اضغط "Add rule"
3. في Branch name pattern اكتب: `main`
4. فعّل:
   - ✅ Require pull request reviews before merging
   - ✅ Require status checks to pass
5. اضغط "Create"

## نصائح مهمة 💡

### التعامل مع الملفات الكبيرة
- GitHub لا يقبل ملفات أكبر من 100 MB
- استخدم Git LFS للملفات الكبيرة

### الأمان
- **لا تضع** كلمات مرور حقيقية في الكود
- استخدم ملف `.env` للبيانات الحساسة
- أضف `.env` إلى `.gitignore`

### تنظيم الـ Commits
- اكتب رسائل commit واضحة ووصفية
- استخدم الأفعال في صيغة الأمر: "إضافة"، "تحديث"، "إصلاح"
- مثال جيد: `"إضافة ميزة طباعة التقارير"`
- مثال سيء: `"تعديلات"`

## الأوامر الأساسية

### حالة الملفات
```bash
git status
```

### تاريخ الـ Commits
```bash
git log --oneline
```

### التراجع عن التعديلات
```bash
# التراجع عن تعديلات غير محفوظة
git checkout -- filename

# التراجع عن آخر commit (مع الحفاظ على التعديلات)
git reset HEAD~1

# التراجع عن آخر commit (حذف التعديلات)
git reset --hard HEAD~1
```

### إنشاء فرع جديد
```bash
git checkout -b feature-name
```

## استكشاف الأخطاء

### خطأ: "Repository not found"
- تأكد من صحة رابط Repository
- تأكد من صلاحيات الوصول

### خطأ: "Permission denied"
- تأكد من تسجيل الدخول بشكل صحيح
- استخدم Personal Access Token بدلاً من كلمة المرور

### خطأ: "Failed to push"
- قم بعمل `git pull` أولاً
- ثم `git push`

### الموقع لا يعمل على GitHub Pages
- تأكد من أن الملف الرئيسي اسمه `index.html`
- تأكد من أن الملف في المجلد الرئيسي
- انتظر 2-3 دقائق ثم جرب مرة أخرى
- امسح cache المتصفح (Ctrl+Shift+R)

## روابط مفيدة

- 📚 [توثيق GitHub](https://docs.github.com)
- 🎓 [تعلم Git](https://git-scm.com/book/ar/v2)
- 🌐 [GitHub Pages](https://pages.github.com)
- 🔑 [Personal Access Tokens](https://github.com/settings/tokens)

## الدعم

إذا واجهت أي مشكلة:
1. راجع قسم استكشاف الأخطاء أعلاه
2. ابحث في [GitHub Community](https://github.community)
3. افتح Issue في المشروع

---

**بالتوفيق في نشر مشروعك! 🎉**
