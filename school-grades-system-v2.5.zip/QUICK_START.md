# دليل البدء السريع ⚡

## خطوات سريعة لتشغيل المشروع

### 1️⃣ افتح الموقع
- افتح ملف `index.html` في أي متصفح ويب

### 2️⃣ سجل الدخول

#### كمعلم 👨‍🏫
```
اسم المستخدم: ahmed
كلمة المرور: 123456
```

#### كمدير 👔
```
اسم المستخدم: admin
كلمة المرور: admin123
```

### 3️⃣ ابدأ الرصد
1. اختر المادة
2. اختر الصف
3. اختر الفصل
4. أدخل الدرجات
5. اضغط "حفظ"

### 4️⃣ استيراد/تصدير Excel
```bash
# تثبيت المكتبة المطلوبة
pip install openpyxl

# تشغيل السكريبت
cd scripts
python excel_handler.py
```

## حسابات المعلمين المتاحة

| المعلم | المستخدم | المادة |
|--------|----------|---------|
| أحمد محمد | ahmed | رياضيات |
| فاطمة علي | fatima | فيزياء |
| محمد حسن | mohammed | كيمياء |
| سارة أحمد | sara | أحياء |
| عمر خالد | omar | لغة عربية |

**كلمة المرور لجميع الحسابات: 123456**

## نشر على GitHub Pages

```bash
# 1. إنشاء repository على GitHub
# 2. رفع الملفات
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin YOUR_REPO_URL
git push -u origin main

# 3. تفعيل GitHub Pages من Settings
```

## مشاكل شائعة وحلولها

### ❌ البيانات لا تُحفظ
✅ **الحل**: تأكد من عدم استخدام التصفح الخاص (Incognito Mode)

### ❌ الطباعة لا تعمل
✅ **الحل**: تأكد من تفعيل JavaScript في المتصفح

### ❌ Excel لا يعمل
✅ **الحل**: قم بتثبيت مكتبة openpyxl:
```bash
pip install openpyxl
```

## روابط مفيدة

- 📖 [دليل الاستخدام الكامل](README.md)
- 🤝 [كيفية المساهمة](CONTRIBUTING.md)
- 🐛 [الإبلاغ عن مشكلة](https://github.com/username/school-grades-system/issues)

## الدعم

للحصول على المساعدة:
1. راجع ملف [README.md](README.md)
2. ابحث في Issues الموجودة
3. افتح Issue جديد

---

**تم التطوير بواسطة Claude - 2026** 🎓
