# دليل تخصيص النظام 🎨

دليل شامل لتخصيص نظام رصد الدرجات حسب احتياجات مدرستك.

## محتويات الدليل
- [تغيير الألوان والتصميم](#تغيير-الألوان-والتصميم)
- [تعديل بيانات المدرسة](#تعديل-بيانات-المدرسة)
- [إضافة/تعديل المواد](#إضافةتعديل-المواد)
- [تغيير عدد الطلاب](#تغيير-عدد-الطلاب)
- [تعديل مكونات الدرجات](#تعديل-مكونات-الدرجات)
- [إضافة حسابات معلمين](#إضافة-حسابات-معلمين)
- [تغيير عدد الفصول](#تغيير-عدد-الفصول)

---

## تغيير الألوان والتصميم

### 1. الألوان الرئيسية

افتح ملف `index.html` وابحث عن قسم `:root` في الـ CSS:

```css
:root {
    --primary: #1a5f7a;        /* اللون الأساسي - أزرق */
    --secondary: #159895;       /* اللون الثانوي - أخضر مزرق */
    --accent: #57c5b6;         /* لون التمييز - أخضر فاتح */
    --success: #2a9d8f;        /* لون النجاح - أخضر */
    --danger: #e76f51;         /* لون التحذير - برتقالي محمر */
    --warning: #f4a261;        /* لون التنبيه - برتقالي */
}
```

#### أمثلة على مجموعات ألوان:

**الأحمر والذهبي (تقليدي):**
```css
--primary: #8B0000;
--secondary: #DAA520;
--accent: #FFD700;
```

**الأزرق والأخضر (حديث):**
```css
--primary: #0066CC;
--secondary: #00AA88;
--accent: #00DDAA;
```

**البنفسجي والوردي (عصري):**
```css
--primary: #6A1B9A;
--secondary: #E91E63;
--accent: #FF4081;
```

### 2. الخطوط

لتغيير الخط المستخدم، عدّل في ملف `index.html`:

```html
<!-- الخط الحالي -->
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;900&family=Cairo:wght@400;600;700;900&display=swap" rel="stylesheet">

<!-- مثال: استخدام خط Almarai -->
<link href="https://fonts.googleapis.com/css2?family=Almarai:wght@300;400;700;800&display=swap" rel="stylesheet">
```

ثم في CSS:
```css
body {
    font-family: 'Almarai', sans-serif;
}
```

---

## تعديل بيانات المدرسة

### في صفحة تسجيل الدخول والهيدر

افتح `index.html` وابحث عن:

```html
<h1>إدارة ناصر التعليمية</h1>
<h2>مدرسة عمر بن الخطاب الثانوية</h2>
```

غيّرها إلى:
```html
<h1>إدارة [اسم الإدارة] التعليمية</h1>
<h2>مدرسة [اسم مدرستك]</h2>
```

### في سكريبت Python

افتح `scripts/excel_handler.py` وعدّل:

```python
title_cell.value = "إدارة ناصر التعليمية"
# غيّرها إلى
title_cell.value = "إدارة [اسم الإدارة] التعليمية"

title_cell.value = "مدرسة عمر بن الخطاب الثانوية"
# غيّرها إلى
title_cell.value = "مدرسة [اسم مدرستك]"
```

---

## إضافة/تعديل المواد

### في الواجهة

افتح `index.html` وابحث عن القائمة المنسدلة:

```html
<select id="subjectSelect" onchange="updateSelection()">
    <option value="">اختر المادة</option>
    <option value="رياضيات">رياضيات</option>
    <option value="فيزياء">فيزياء</option>
    <!-- أضف المواد الجديدة هنا -->
    <option value="حاسب آلي">حاسب آلي</option>
    <option value="تربية فنية">تربية فنية</option>
</select>
```

### في JavaScript

افتح `app.js` وأضف المواد الجديدة في قائمة المعلمين:

```javascript
teachers: [
    { id: 1, username: 'ahmed', password: '123456', name: 'أحمد محمد', subject: 'رياضيات' },
    // أضف معلمين جدد
    { id: 6, username: 'khaled', password: '123456', name: 'خالد سعيد', subject: 'حاسب آلي' },
]
```

---

## تغيير عدد الطلاب

### في JavaScript

افتح `app.js` وابحث عن دالة `initializeStudents()`:

```javascript
// الكود الحالي (30 طالب)
for (let i = 1; i <= 30; i++) {
    appData.students[key].push({
        id: i,
        name: `طالب ${i}`,
        grade: grade,
        class: classNum
    });
}

// للتغيير إلى 35 طالب مثلاً
for (let i = 1; i <= 35; i++) {
    // ...
}
```

### في Python

افتح `scripts/excel_handler.py` وعدّل:

```python
# الكود الحالي
for i in range(1, 31):  # 30 طالب
    ws.append([i, f'طالب {i}'])

# للتغيير إلى 35 طالب
for i in range(1, 36):  # 35 طالب
    ws.append([i, f'طالب {i}'])
```

---

## تعديل مكونات الدرجات

### تغيير الدرجات القصوى

افتح `index.html` وعدّل في جدول الدرجات:

```html
<!-- الحالي -->
<th>التقييم (10)</th>
<th>الواجب (5)</th>
<th>الكشكول (5)</th>
<th>الاختبار الأول (15)</th>
<th>الاختبار الثاني (15)</th>
<th>المجموع (50)</th>

<!-- مثال: تغيير إلى 100 درجة -->
<th>التقييم (20)</th>
<th>الواجب (10)</th>
<th>الكشكول (10)</th>
<th>الاختبار الأول (30)</th>
<th>الاختبار الثاني (30)</th>
<th>المجموع (100)</th>
```

وعدّل في حقول الإدخال:
```html
<input type="number" min="0" max="20" ... >  <!-- بدلاً من max="10" -->
```

### إضافة مكون جديد للدرجات

في `index.html`، أضف عمود جديد في جدول الدرجات:

```html
<th>المشاركة (5)</th>
```

وأضف حقل الإدخال في JavaScript:

```javascript
<td><input type="number" min="0" max="5" value="${savedGrades.participation}" data-student="${student.id}" data-type="participation" onchange="calculateTotal(this)"></td>
```

لا تنسَ تحديث دالة الحفظ في `app.js`:

```javascript
const grades = {
    evaluation: parseFloat(inputs[0].value) || 0,
    homework: parseFloat(inputs[1].value) || 0,
    notebook: parseFloat(inputs[2].value) || 0,
    exam1: parseFloat(inputs[3].value) || 0,
    exam2: parseFloat(inputs[4].value) || 0,
    participation: parseFloat(inputs[5].value) || 0,  // جديد
    total: 0
};

grades.total = grades.evaluation + grades.homework + grades.notebook + 
               grades.exam1 + grades.exam2 + grades.participation;
```

---

## إضافة حسابات معلمين

افتح `app.js` وعدّل قائمة المعلمين:

```javascript
teachers: [
    { id: 1, username: 'ahmed', password: '123456', name: 'أحمد محمد', subject: 'رياضيات' },
    { id: 2, username: 'fatima', password: '123456', name: 'فاطمة علي', subject: 'فيزياء' },
    // أضف معلمين جدد هنا
    { id: 6, username: 'layla', password: '123456', name: 'ليلى إبراهيم', subject: 'حاسب آلي' },
    { id: 7, username: 'youssef', password: '123456', name: 'يوسف محمود', subject: 'تربية فنية' },
]
```

**ملاحظة مهمة**: غيّر كلمات المرور الافتراضية في بيئة الإنتاج!

---

## تغيير عدد الفصول

### من 5 إلى 8 فصول مثلاً

في `index.html`، أضف بطاقات اختيار فصول جديدة:

```html
<div class="selection-card" onclick="selectClass('6')">
    <h3>الفصل 6</h3>
</div>
<div class="selection-card" onclick="selectClass('7')">
    <h3>الفصل 7</h3>
</div>
<div class="selection-card" onclick="selectClass('8')">
    <h3>الفصل 8</h3>
</div>
```

في `app.js`، عدّل دالة `initializeStudents()`:

```javascript
const classes = ['1', '2', '3', '4', '5', '6', '7', '8'];  // بدلاً من ['1', '2', '3', '4', '5']
```

وفي جميع الحلقات:
```javascript
['1', '2', '3', '4', '5', '6', '7', '8'].forEach(classNum => {
    // ...
});
```

---

## نصائح للتخصيص

### 1. النسخ الاحتياطية
قبل أي تعديل، احتفظ بنسخة احتياطية:
```bash
cp index.html index.html.backup
cp app.js app.js.backup
```

### 2. الاختبار
- اختبر جميع التعديلات محلياً قبل النشر
- جرّب على متصفحات مختلفة
- تأكد من عمل جميع الميزات

### 3. التوثيق
- وثّق أي تعديلات تجريها
- احتفظ بقائمة بالتخصيصات
- أضف تعليقات في الكود

### 4. الأمان
- غيّر كلمات المرور الافتراضية
- لا تضع بيانات حساسة في الكود
- استخدم HTTPS عند النشر

---

## أمثلة على تخصيصات شائعة

### مثال 1: مدرسة ابتدائية
- عدد الطلاب: 25 بدلاً من 30
- عدد الفصول: 3 بدلاً من 5
- الدرجات: من 100 بدلاً من 50

### مثال 2: مدرسة متوسطة
- إضافة مادة "حاسب آلي" و"تربية فنية"
- تغيير الألوان إلى الأزرق والأخضر
- إضافة 5 معلمين جدد

### مثال 3: معهد تدريبي
- تغيير "الصف" إلى "المستوى"
- تغيير "الفصل" إلى "المجموعة"
- تغيير "الطالب" إلى "المتدرب"

---

## الدعم

إذا واجهت أي صعوبة في التخصيص:
1. راجع هذا الدليل بعناية
2. ابحث في Issues على GitHub
3. افتح Issue جديد مع وصف المشكلة

---

**نتمنى لك تجربة تخصيص ممتعة! 🎨**
